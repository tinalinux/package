//
//  AppDelegate.h
//  cooee
//
//  Created by apk on 2014/11/14.
//  Copyright (c) 2014年 cooee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

